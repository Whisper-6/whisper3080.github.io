﻿---
title: ARC090C Avoiding Collision
date: 2025-02-23 19:04:00
tags: [图论, 思维]
categories:
  - [算法竞赛, 题, AtCoder]
---

**题意**：给出一张含有 $n$ 个点 $m$ 条带权边的无向图。

有两人分别在 $S,T$，他们要前往对方的位置。

求两人都走最短路且不相遇（点上和边上相遇都不行）的方案数。答案对 $10^9+7$ 取模。

$n\leq 10^5$，$m\leq 2\times 10^5$，时限 $\texttt{2s}$。

<!-- more -->

------------

建立从 $S\rightarrow T,\ T\rightarrow S$ 的最短路 $\rm DAG$。

记 $f_S[u]$ 为 $u\leftrightarrow S$ 的最短路径数，$d_S[u]$ 为 $S\leftrightarrow u$ 的最短距离。

类似地定义 $f_T[u],d_T[u]$。

记 $dis=d_S[T]$，记 $S,T$ 之间的最短路长度。

若允许两人相遇，则方案数为两个 $\rm DAG$ 路径数的乘积。即 $f_S[T]^2$。

考虑容斥，减去不合法的方案。

不难发现，在走最短路的基础上，两人若相遇，只能相遇一次。

枚举在那个点或那条边上相遇：

- 在点 $u$ 上相遇

  条件：$d_S[u]+d_T[u]=dis$ 且 $d_S[u]=d_T[u]$
  
  方案数：$f_S[u]^2f_T[u]^2$

- 在边 $(u,v,w)$ 上相遇（不包括端点）（注意 $u,v$ 可以交换）

  条件：$d_S[u]+d_T[v]+w=dis$ 且 $\big(d_S[u],d_S[u]+w\big)\cap\big(d_S[u],d_S[u]+w\big)\neq \varnothing$
  
  方案数：$f_S[u]^2f_T[v]^2$
  

复杂度 $O(n\log n)$。

