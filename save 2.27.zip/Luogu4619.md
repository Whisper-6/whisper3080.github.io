﻿---
title: Luogu4619 [SDOI2018] 旧试题
date: 2025-02-18 11:33:58
tags: [数论]
mathjax: true
categories:
  - [算法竞赛, 题, 洛谷]
---

- **参考资料**：《数论选讲》in APIO2024 by zhoukangyang.（多元积性函数）

讲义里提到本题的 $O(N\sqrt{N})$ 做法，但没有细说。我将详细地陈述此做法。

<!-- more -->

- **Notations**：$N$ 为 $A,B,C$ 的上界；记前缀和 $S_F(n)=\sum_{i=1}^nF(i)$。

## 基本概念

- **多元积性函数**

  函数 $f(a,b,c)$ 满足当 $abc\perp xyz$ 时，有 $f(ax,by,cz)=f(a,b,c)f(x,y,z)$，则称 $f$ 为（三元）积性函数。

- **Observation**：令 $f(i,j,k)=d(ijk)$，则 $f$ 是积性函数。问题转化为三元积性函数的矩阵和。

- **积性分解**

  将 $x,y,z$ 分解为 $x=\prod_{i=1}^mp_i^{a_i}$，$y=\prod_{i=1}^mp_i^{b_i}$，$z=\prod_{i=1}^mp_i^{c_i}$，对于积性函数 $f$
  $$
  f(x,y,z)=\prod_{i=1}^mf(p^{a_i},p^{b_i},p^{c_i})
  $$

- **狄利克雷卷积**

  三元积性函数的狄利克雷卷积定义为
  $$
  (f*g)(x,y,z)=\sum_{a|x}\sum_{b|y}\sum_{c|z}f(a,b,c)g(x/a,y/b,z/c)
  $$
  类似一元的情况，有如下性质成立：

  - 积性函数的卷积是积性函数。
  - 积性函数的逆是积性函数。

- **贝尔级数**

  在素数 $p$ 处观测积性函数 $f(x,y,z)$，定义贝尔级数为三元形式幂级数
  $$
  \mathcal F_p(u_1,u_2,u_3)=\sum_{i=0}^{+\infty}\sum_{j=0}^{+\infty}\sum_{k=0}^{+\infty}f(p^i,p^j,p^k)u_1^iu_2^ju_3^k
  $$
  类似一元的情况，两个函数卷积，对应的贝尔级数相乘。

## 低阶拟合法

模仿 Powerful Number 的思路，构造一个数论函数 $g$ 使得 $f,g$ 在素数幂次较低时相等，然后做除法 $h=f/g$，$h$ 的非零元素有希望较少。

计算 $f$ 的矩阵和时
$$
\begin{aligned}
S_f(A,B,C)&=\sum_{i=1}^A\sum_{j=1}^B\sum_{k=1}^Cf(i,j,k)\\
&=\sum_{i=1}^A\sum_{j=1}^B\sum_{k=1}^C\sum_{x|i}\sum_{y|j}\sum_{z|j}h(x,y,z)g(i/x,j/y,k/z)\\
&=\sum_{x=1}^A\sum_{y=1}^B\sum_{z=1}^Ch(x,y,z)\sum_{i=1}^{\lfloor A/x\rfloor}\sum_{j=1}^{\lfloor B/y\rfloor}\sum_{j=1}^{\lfloor C/z\rfloor}g(i,j)\\
&=\sum_{x=1}^A\sum_{y=1}^B\sum_{z=1}^Ch(x,y,z)S_g(\lfloor A/x\rfloor,\lfloor B/y\rfloor,\lfloor C/z\rfloor)\\
\end{aligned}
$$
如果 $h$ 稀疏，且 $g$ 的矩阵和易求，我们就得到了一个不错的算法。

一个自然的想法是，构造 $g(i,j,k)=d(i)d(j)d(k)$，则

- $g$ 容易计算。
  $$
  \begin{aligned}
  S_g(A,B,C)&=\sum_{i=1}^A\sum_{j=1}^B\sum_{k=1}^Cd(i)d(j)d(k)\\
  &=\left(\sum_{i=1}^Ad(i)\right)\left(\sum_{j=1}^Bd(j)\right)\left(\sum_{k=1}^Cd(k)\right)\\
  &=S_d(A)S_d(B)S_d(C)
  \end{aligned}
  $$

	$O(N)$ 预处理 $S_d$ 后容易 $O(1)$ 计算。

- $g$ 和 $f$ 在低阶处相等。

  可以发现 $g(p^k,1,1)=f(p^k,1,1)$，$g(1,p^k,1)=f(1,p^k,1)$，$g(1,1,p^k)=f(1,1,p^k)$。

  为了更直观地说明这一点，构造贝尔级数。
  $$
  \begin{matrix}
  \begin{aligned}
  f(p^i,p^j,p^k)&=d(p^{i+j+k})=i+j+k+1\\
  \mathcal F_p(u_1,u_2,u_3)&=\sum_{i=0}^{+\infty}\sum_{j=0}^{+\infty}\sum_{k=0}^{+\infty}f(p^i,p^j,p^k)u_1^iu_2^ju_3^k\\
  &=\sum_{i=0}^{+\infty}\sum_{j=0}^{+\infty}\sum_{k=0}^{+\infty}(i+j+k+1)u_1^iu_2^ju_3^k
  \end{aligned}\\\\
  \begin{aligned}
  g(p^i,p^j,p^k)&=d(p^i)d(p^j)d(p^k)=(i+1)(j+1)(k+1)\\
  \mathcal G_p(u_1,u_2,u_3)&=\sum_{i=0}^{+\infty}\sum_{j=0}^{+\infty}\sum_{k=0}^{+\infty}g(p^i,p^j,p^k)u_1^iu_2^ju_3^k\\
  &=\sum_{i=0}^{+\infty}\sum_{j=0}^{+\infty}\sum_{k=0}^{+\infty}(i+1)(j+1)(k+1)u_1^iu_2^ju_3^k
  \end{aligned}\\\\
  \mathcal H_p=\mathcal F_p/\mathcal G_p
  \end{matrix}
  $$
  $\mathcal F$ 和 $\mathcal G$ 的系数在“三条棱”上是相等的，根据幂级数逆元的知识，可以发现 $\mathcal H$ 在这三条棱上都是 $1$，没有更多的项。即是说：
  $$
  h(1,1,p^k)=h(1,p^k,1)=h(p^k,1,1)=0
  $$
  不仅如此，计算发现：
  $$
  \begin{matrix}
  h(1,1,p)=h(1,p,1)=h(p,1,1)=-1\\
  h(1,1,p^2)=h(1,p^2,1)=h(p^2,1,1)=2
  \end{matrix}
  $$
  除了上述项，其余都是零。
  
- $h$ **密度的分析**

  枚举量就是 $h(1\sim A,1\sim B,1\sim C)$ 的非零项数量，将条件放宽为 $h(x,y,z)$，$xyz\leq ABC\leq N^3$。

  记 $s(n)$ 为满足 $xyz=n$ 的非零 $h(x,y,z)$ 个数，则复杂度为 $O(S_s(N^3))$。

  可以证明 $s$ 是积性函数，且 $s(p)=0$，$s(p^2)=3$。

  - **Lemma**: 对于数论函数 $F$，找出最小的 $k_0\geq 1$ 满足 $F(p^{k_0})\neq 0$。记 $c$ 为 $F(p^{k_0})$ 的最大值，其余 $F(p^k)=O({\rm poly}(k))$，则 $S_F(n)=O(n^{1/k_0}\log^{c-1}n)$。

  根据这个引理，可以得到 $S_s(n)=O(n^{1/2}\log^2n)$，对应复杂度 $O(N\sqrt{N}\log^2 N)$。

  此界太过宽松，这是因为我们将矩形区域粗暴地放缩成了双曲区域 $xyz\leq ABC$，两者的面积比就是 $\Theta(\log^2N)$。为了去除多余的 log 因子，必须考虑为矩形区域。

  定义三元数论函数 $v(x,y,z)=[h(x,y,z)\neq 0]$，我们的目标是估计 $v$ 的矩阵和。

  令 $v_1$ 满足 $v_1(p,p,1)=v_1(p,1,p)=v_1(1,p,p)=1$，其余都是 $0$，$v_2=v-v_1$。显然，$v\leq v_1*v_2$。

  先考察 $v_1$ 的矩阵和，$v_1(a,b,c)$ 总是可以写作 $v_1(xy,xz,yz)$，枚举 $x,y,z$ 进行计数：
  $$
  \begin{aligned}
  S_{v_1}(A,B,C)&=\sum_{x=1}^{+\infty}\sum_{y=1}^{+\infty}\sum_{z=1}^{+\infty}[x\perp y][x\perp z][y\perp z][xy\leq A][xz\leq B][yz\leq C]\\
  &\leq \sum_{x=1}^{+\infty}\sum_{y=1}^{+\infty}\sum_{z=1}^{+\infty}[xy\leq A][xz\leq B][yz\leq C]\\
  &\sim\sum_{x=1}^{+\infty}\sum_{y=1}^{+\infty}[xy\leq A]\min(B/x,C/y)\\
  \end{aligned}
  $$
  用讨论将 $\min$ 拆掉，$C/y$ 较小的部分是
  $$
  \begin{aligned}
  &\sim C\sum_{x=1}^{\sqrt{AB/C}}\sum_{Cx/B\leq y\leq A/x}^{+\infty}1/y\\
  &\sim C\sum_{x=1}^{\sqrt{AB/C}}\ln(AB/Cx^2)\\
  &\sim C\cdot T\Big(\sqrt{AB/C}\Big)
  \end{aligned}
  $$
  根据对称性，另一部分是 $B\cdot T\Big(\sqrt{AC/B}\Big)$。

  其中 $T(n)=\sum_{i=1}^n\ln(n/i)$，这是一个经典形式
  $$
  \begin{aligned}
    T(2n)&=\sum_{i=1}^{2n}\ln(2n/i)\\
    &=\sum_{i=1}^{n}\big(\ln 2+\ln(n/i)\big)+\sum_{i=n+1}^{2n}\ln(2n/i)\\
    &=(\ln2)\cdot 2n+T(n)\\
    &=O(n)+T(n)
    \end{aligned}
  $$
  解得 $T(n)=O(n)$。代入得 $S_{v_1}(A,B,C)=O(\sqrt{ABC})$。

  考虑 $v_1*v_2$ 的矩阵和
  $$
  \begin{aligned}
    S_{v}(N,N,N)&=\sum_{x,y,z\leq N}v_2(x,y,z)S_{v_1}(N/x,N/y,N/z)\\
    &=\sum_{x,y,z\leq N}v_2(x,y,z)\sqrt{\dfrac{N^3}{xyz}}
  \end{aligned}
  $$
  记 $s_2(n)$ 为满足 $xyz=n$ 的非零 $v_2(x,y,z)$ 个数。$s_2$ 的全零前缀更长，根据引理，$v_2(x,y,z)$ 在 $xyz\leq n$ 的非零个数不超过 $S_{s_2}(n)=\tilde O(n^{1/3})$，密度可以估计为 $\tilde O(n^{-2/3})$。枚举 $T=xyz$，复杂度可以估计为
  $$
  \begin{aligned}
    \sum_{T\leq N^3}\sqrt{\dfrac{N^3}{T}}s_2(T)&=\sum_{T\leq N^3}\sqrt{\dfrac{N^3}{T}}\tilde O(T^{-2/3})\\
    &= N^{3/2}\sum_{T\leq N^3}\tilde O(T^{-7/6})\\
    &= O(N^{3/2})
  \end{aligned}
  $$
  综上，我们证明了枚举量是 $O(N\sqrt{N})$。

