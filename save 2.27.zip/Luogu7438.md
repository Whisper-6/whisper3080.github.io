﻿---
title: Luogu7438 更简单的排列计数
date: 2025-02-25 14:03:21
tags: [多项式计数]
categories:
  - [算法竞赛, 题, 洛谷]
---

**题意**：设 $\text{cyc}_p$ 将长为 $n$ 的排列 $p$ 当成置换时所能分解成的循环个数。给定两个整数 $n,k$ 和一个 $k-1$ 次多项式，对 $1\leq m\leq n$ 分别求：
$$
\sum\limits_{p}F(\text{cyc}_{p})
$$

其中 $p$ 是长度为 $m$ 且不存在位置 $i$ 使得 $p_i=i$ 的排列。

$n\leq 6\times 10^5$，$k\leq100$，时限 $\texttt{0.8s}$。

<!-- more -->

------------

考虑对 $1\leq i\leq n$ 分别求出循环个数为 $i$ 的错排的个数。然后多点求值得到贡献系数即可算出答案。

考虑如何用生成函数刻画错排。错排可以看做大小 $>1$ 的循环组成的无序集合。

大小 $>1$ 的循环的 $\rm EGF$ ： $-x-\ln(1-x)$

错排的 $\rm EGF$ : $e^{-x-\ln(1-x)}$

我们要根据循环个数分类，于是改写为二元函数 $G(x,y)=e^{\small y(-x-\ln(1-x))}$。

我们的目标即是求出 $[x^n]e^{\small y(-x-\ln(1-x))}$ ，然而 $y$ 的次数上界和 $n$ 有关，没有利用题目中 $k$ 较小的性质。

将多项式 $F$ 改写为牛顿级数，这部分容易 $O(k^2)$ 暴力完成。

然后分项求和，即对于 $0\leq t\leq k$ ，求

$$
\sum\limits_{p}\dbinom{\text{cyc}_{p}}{t}
$$

我们只需将生成函数改写为 $G(x,y)=e^{\small (1+y)(-x-\ln(1-x))}$ 。其中的 $1+y$ 表示对于每个循环可选可不选。

此时，求出 $[x^n]e^{\small (1+y)(-x-\ln(1-x))}$ 再与 $F$ 的系数（只有 $k$ 个）点乘即可得到最终答案。


考虑系数递推。

$$
\begin{aligned}
\dfrac{\partial}{\partial x}G(x,y)&=(1+y)\frac{x}{1-x}G(x,y)\\
[x^n]\dfrac{\partial}{\partial x}G(x,y)&=[x^n](1+y)\frac{x}{1-x}G(x,y)\\
(n+1)[x^{n+1}]G(x,y)&=[x^{n-1}](1+y)\frac{1}{1-x}G(x,y)\\
(n+1)[x^{n+1}y^m]G(x,y)&=[x^{n-1}y^{m-1}]\frac{1}{1-x}G(x,y)+[x^{n-1}y^m]\frac{1}{1-x}G(x,y)\\
(n+1)[x^{n+1}y^m]G(x,y)&=\sum\limits_{i=0}^{n-1}\Big([x^iy^{m-1}]G(x,y)+[x^iy^m]G(x,y)\Big)
\end{aligned}
$$

边界为 $[x^0]G=1,[x^1]G=0$。

按照上式递推即可，使用前缀和优化并滚动数组，复杂度为 $O(nk)$。

