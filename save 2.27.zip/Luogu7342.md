﻿---
title: Luogu7342 『MdOI R4』Destiny
date: 2025-02-25 14:40:00
tags: [多项式计数]
categories:
  - [算法竞赛, 题, 洛谷]
---

**题意**：一个长度为 $n$ 的序列 $a_{0\sim n-1}$ 的权值 $v(a)$ 定义为：

- $n=1$ 时为 $v(a)=a_0$。
- $n>1$ 时为它所有子区间的权值之和，也就是 $v(a_0,a_1,\ldots,a_{n-1})=\sum\limits_{i=0}^{n-2}\sum\limits_{j=0}^{n-i-1}v(a_j,a_{j+1},\ldots,a_{j+i})$. 

给定一个序列，求它的的权值，答案对 $998244353$ 取模。

这个序列是这样生成的：输入序列 $b_{0\sim k-1}$，令 $a_i=b_{i\bmod k}$。

$n\leq 10^9$，$k\leq 10^5$，时限 $\texttt{2s}$。

<!-- more -->

------------

设 $\left|\begin{matrix}n\\m\end{matrix}\right|$ 表示长度为 $n$ 的序列中第 $m$ 个位置的贡献系数。

在计算 $\left|\begin{matrix}n\\m\end{matrix}\right|$ 时，考虑每个覆盖 $m$ 的区间 $[L,R]$ 的贡献。

分别枚举 $l=m-L,\ r=R-m$，可得 ：

$$
\begin{aligned}
\left|\begin{matrix}n\\m\end{matrix}\right|&=-\left|\begin{matrix}n\\m\end{matrix}\right|+\sum\limits_{l}^m\sum\limits_{r=1}^{n-m}\left|\begin{matrix}l+r\\l\end{matrix}\right|\\
2\left|\begin{matrix}n\\m\end{matrix}\right|&=\sum\limits_{l=0}^m\sum\limits_{r=1}^{n-m}\left|\begin{matrix}l+r\\l\end{matrix}\right|\\
\end{aligned}
$$

设 $g_{n,m}=\sum\limits_{l=0}^m\sum\limits_{r=1}^{n-m}\left|\begin{matrix}l+r\\l\end{matrix}\right|$，不难得到递推 ：

$$
g_{n,m}=g_{n-1,m}+g_{n-1,m-1}-g_{n-2,m-1}+\left|\begin{matrix}n\\m\end{matrix}\right|
$$
结合 $2\left|\begin{matrix}n\\m\end{matrix}\right|=g_{n,m}$ 可得 ：

$$
\left|\begin{matrix}n\\m\end{matrix}\right|=2\left|\begin{matrix}n-1\\m\end{matrix}\right|+2\left|\begin{matrix}n-1\\m-1\end{matrix}\right|-2\left|\begin{matrix}n-2\\m-1\end{matrix}\right|
$$
这个递推式非常漂亮，系数都是常数。

-----

设 $F_n(x)=\sum\limits_{i=0}x^i\left|\begin{matrix}n\\i\end{matrix}\right|$，即第 $n$ 行的 OGF。

则有生成函数形式的递推式 ：

$$
F_n(x)=2(x+1)F_{n-1}(x)-2xF_{n-2}(x)
$$
可以视作二阶线性递推，边界为 $F_1(x)=1,F_2=1+x$。

为了凑一个好看的式子（减小常数），钦定 $F_1(x)=\frac{1}{2}$，最后特判。

利用特征方程可解得 ：

$$
F_n(x)=\dfrac{\big(1+x+\sqrt{1+x^2}\big)^n-\big(1+x-\sqrt{1+x^2}\big)^n}{4\sqrt{1+x^2}}
$$
答案即为：

$$
\begin{aligned}
{\rm Ans}&=\sum\limits_{i=0}^{n-1}b_{i\bmod k}\left|\begin{matrix}n\\i\end{matrix}\right|\\
&=\sum\limits_{i=0}^{n-1}b_{i\bmod k}[x^i]F_n(x)
\end{aligned}
$$

于是，我们只需求出 $F_n(x)\bmod (x^k-1)$，即可得到答案。

使用循环卷积快速幂即可。但循环卷积中没有除法，定义式分母中的 $4\sqrt{1+x^2}$ 难以去除。实际上，$\sqrt{1+x^2}$ 的循环多项式也没有好的定义。

考虑扩域，维护形为 $F+G\sqrt{1+x^2}$ 的多项式，然后利用 $\sqrt{1+x^2}^2=1+x^2$ 来计算。

由于计算 $1+x\pm\sqrt{1+x^2}$ 的幂次时， $F+G\sqrt{1+x^2}$ 中 $F$ 总是有限多项式，可以证明，最终 $F$ 部分的系数一定抵消。故只提取 $G$ 即可得到答案。

复杂度为 $O(k\log k\log n)$。

-----

卡常技巧：

- 计算 $(a+b\sqrt{w})(c+d\sqrt{w})=ac+wbd+(ad+bc)\sqrt{w}$ 时，可以计算 $ac,bd,(a+c)(b+d)$，即可通过加减法得到所需的 $ad+bc$ 。

  这需要计算 $a,b,c,d$ 的 DFT，再进行三次 IDFT，共 $7$ 次。

- $1+x+\sqrt{1+x^2},1+x-\sqrt{1+x^2}$ 之间的关系类似于共轭，于是可以证明，两者的 $n$ 次幂中，$\sqrt{1+x^2}$ 的系数仍为相反数。

  因此只需计算一次快速幂。
  
- 计算快速幂时，将求平方精细实现。复用 DFT 结果。
  

