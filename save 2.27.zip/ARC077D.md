﻿---
title: ARC077D
date: 2025-02-23 20:55:03
tags:
---

**题意** ： 对于非空串 $S$，定义 $f(S)$ 是在 $S$ 后面添加一些（至少一个）字符得到的最短平方串。

现在给出平方串 $S$，记 $T=f(f(f(...f(S))))$ （可以认为有无穷多个 $f$）

给出 $l,r$，询问 $T[l,r]$ 中各个字符的出现次数。（字符集为小写英文字母）

$|S|\leq 2\times 10^5$，$l,r\leq 10^{18}$，时限 $\texttt{2s}$。

<!-- more -->

------------

考虑给出 $S$ 如何求解 $f(SS)$。

设 $S$ 的周期集合为 ${\rm per}(S)$，求出 $\min\limits_{p\in{\rm per(SS)},p>|S|}p$，即大于一半的最小循环节。

将 $SS$ 补成两个 $p$ 即可。

记 $S$ 的最短循环节前缀 为 $T$，$p$ 所对应的串即为 $ST$。记 $g(S)$ 为 $S$ 的最小循环节前缀。

也即：$SS\rightarrow Sg(S)Sg(S)$。

由于会重复无限次操作，我们只需考虑前半部分，即 $S\rightarrow Sg(S)$。

观察这一操作有何规律，能发现：

- $g(S)$ 为整循环节。

  $Sg(S)$ 的最小循环节与 $S$ 的相同，且也是整循环节。

  记 $G=g(S)$，操作的效果为：
  $$
  S\rightarrow SG\rightarrow SG^2 \rightarrow SG^3...
  $$
  容易在 $O(\Sigma)$ 内求解。

- $g(S)$ 不是整循环节。

  $Sg(S)$ 的最小循环节为 $S$，且也不是整循环节。

  **证明**：假设 $T=Sg(S)$ 有小于 $|S|$ 的周期 $p$。

  注意到 $p$ 同时也是 $S$ 的周期，则有 $|g(S)|\leq p$。

  考虑 $i\in \big[|S|+1,|T|\big]$，由于 $g(S)$ 是 $S$ 的前缀，又有 $T[i]=T[i-|S|]$。

  根据周期有 $T[i]=T[i-p]$，由于 $|g(S)|\leq p\Rightarrow i-p\leq |S|$，此时 $T[i-p]$ 已经是 $S$ 的一部分。

  根据 $S$ 的周期 $g(S)$，又有 $i-|S|=i-p\pmod{|g(s)|}$ 即 $|S|=p\pmod{|g(S)|}$。

  那么，由于 $p<|S|$，有 $p\leq |S|-|g(S)|$。

  根据弱周期引理，$S$ 有新的周期 $\gcd(|g(S)|,p)$。

  由于 $g(S)$ 已经是最小周期，故 $p$ 一定是 $g(S)$ 的倍数。（否则会得到更小的周期）

  注意到 $p=|S|\neq 0\pmod{|g(S)|}$，矛盾。 $\square$

  记 $G=g(S)$，操作的效果为：
  $$
  S\rightarrow SG\rightarrow SGS \rightarrow SGSSG...
  $$
  （记第 $i$ 此操作后的串为 $F_i$，有 $F_0=S,F_1=SG,F_i=F_{i-1}+F_{i-2}$）

  串的长度是指数增加的，不难做到 $O\big(|\Sigma|{\rm poly}(\log r)\big)$。

  还需用一次 $O(|S|)$ 的 $\rm KMP$ 求出 $G$。

