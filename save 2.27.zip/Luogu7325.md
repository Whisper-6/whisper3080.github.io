﻿---
title: Luogu7325 [WC2021] 斐波那契
date: 2025-02-25 11:25:20
tags: [数论]
categories:
  - [算法竞赛, 题, 洛谷]
---

**题意**：给出 $T,m$，有 $T$ 组询问，每次询问给出 $a,b$，定义数列 $G_0=a,\ G_0=b$，当 $n>1$ 时 $G_n=G_{n-1}+G_{n-2}$，求最小的满足 $G_p \bmod m=0$ 的 $p$。   

$T,m\leq 10^5$，时限 $\texttt{1s}$。

<!-- more -->

-----

记 $F$ 为斐波那契数列，则 $G_n=aF_{n-1}+bF_{n-2}$。

模 $m$ 下斐波那契数列的循环节长度是 $O(m)$ 的（证明从略），故 $G_m\bmod m$ 的循环节也是 $O(m)$，只用考虑前 $O(m)$ 项。

即求满足 $aF_{n-1}+bF_{n-2}\equiv 0\pmod m$ 的最小的 $n$。一个自然的想法是将 $a,b$ 提取到一侧，$F_{n-1},F_{n-2}$ 提取到另一侧，然后用 Hash 维护。但并不总是能直接求逆。

记 $d=\gcd(a,b,m)$，记 $a',b',m'$ 为 $a,b,m$ 同除 $d$ 的结果，可得等价方程 $a'F_{n-1}\equiv -b'F_{n-2}\pmod {m'}$。

可知 $\gcd(a'F_{n-1},m')=\gcd(-b'F_{n-2},m')$ 即 $\gcd(a',m')\gcd(F_{n-1},m')=\gcd(-b,m')\gcd(F_{n-2},m')$。又注意到 $\gcd(F_{n-1},F_{n-2})=\gcd(a',b',m')=1$，故只有可能是 $\gcd(F_{n-1},m')=\gcd(-b,m')$，$\gcd(a',m')=\gcd(F_{n-2},m')$ （实现了条件的参数分离）。

记 $q_1=\gcd(F_{n-1},m'),q_2=\gcd(F_{n-2},m')$，可以写出 $(a'/q_2)(F_{n-1}/q_1)\equiv (-b'/q_1)(F_{n-2}/q_2)\pmod {m'/q_1q_2}$。

此时满足互质，可以求逆变为 $(F_{n-1}/q_1)/(F_{n-2}/q_2)\equiv (-b'/q_1)/(a'/q_2)\pmod {m'/q_1q_2}$

于是，在模数 $m'$ 下（模数是由 $a,b$ 决定的）对于候选答案 $n$，记为三元组 
$$
\left(\gcd(F_{n-1},m'),\gcd(F_{n-2},m'),\dfrac{F_{n-1}/\gcd(F_{n-1},m')}{F_{n-2}/\gcd(F_{n-1},m')}\bmod {m'/\gcd(F_{n-1}F_{n-2},m')}\right)
$$
对于询问 $a,b$ 写成三元组 
$$
\left(\gcd(b',m'),\gcd(a',m'),\dfrac{-b'/\gcd(b',m')}{a'/\gcd(a',m')}\bmod {m'/\gcd(a'b',m')}\right)
$$
然后到 Hash 表中查询。

对每个模数分别预处理，总复杂度为 $O\big((\sigma(m)+T)\log m\big)$。（其中 $\sigma(m)$ 是约数之和）

