﻿---
title: Luogu7440 「KrOI2021」Feux Follets
date: 2025-02-25 14:06:28
tags: [多项式计数]
categories:
  - [算法竞赛, 题, 洛谷]
---

**题意**：给定两个整数 $n,k$ 和一个 $k-1$ 次多项式，对 $1\leq m\leq n$ 分别求
$$
\sum\limits_{p}F(\text{cyc}_{p})
$$

其中 $p$ 是长度为 $m$ 的错排。

$n,k\leq 10^5$，时限 $\texttt{2s}$。

<!-- more -->

------------

- **前置芝士**：转置原理。

继承 Luogu7439，仍然首先搞一手多点求值，则有

$$
{\rm Ans}[k]=\sum\limits_{i}F(i)[x^ky^i]e^{\small y(-x-\ln(1-x))}
$$
记 $s_i=F(i),\ G(x,y)=e^{\small y(-x-\ln(1-x))}$。

以线性变换的角度来看，将 ${\rm Ans}$ 视为输出向量，$s$ 视为输入向量，则贡献矩阵 $A_{k,i}=[x^ky^i]G(x,y)$。

考虑该变换的转置，即 $t=A^Ts$ ，写出和式 ：

$$
t_k=\sum\limits_{i}s_i[x^iy^k]G(x,y)
$$
考虑 $t_k$ 的生成函数 $T(y)$ ，则可写作 $T(y)=\sum\limits_{i}s_i[x^i]G(x,y)$

将 $G(x,y)$ 按 $x$ 切分，设 $G_i(y)=[x^i]G(x,y)$。

求导可得

$$
\dfrac{\partial}{\partial x}G(x,y)=y\frac{x}{1-x}G(x,y)
$$
由此不难得到递推式

$$
G_{i}=\dfrac{i-1}{i}G_{i-1}+\dfrac{y}{i}G_{i-2}
$$
边界为 $G_0=1$ ，为了方便，令 $G_{-1}=0$ ，这样就能一直套用递推式。

将转移写成矩阵 $W_i=\begin{bmatrix}0&1\\\frac{y}{i}&\frac{i-1}{i}\end{bmatrix}$ ，满足 $\begin{bmatrix}G_{i-1}\\G_i\end{bmatrix}=W_i[G_{i-2},G_{i-1}]$

则有 $\begin{bmatrix}G_{i-1}\\G_i\end{bmatrix}=W_iW_{i-1}...W_1[0,1]$ ，于是 $W_iW_{i-1}...W_1=\begin{bmatrix}?&G_{i-1}\\?&G_{i}\end{bmatrix}$

则答案可以改写为 ：
$$
\sum\limits_{i=1}^ns_iW_iW_{i-1}..W_1
$$
最终取出矩阵右下角即为答案。

这可以利用分治 FFT 计算。设
$$
\begin{aligned}
P_{[l,r)}&=W_{r-1}W_{r-2}\cdots W_l\\
Q_{[l,r)}&=\sum\limits_{i\in[l,r)}s_iW_{i}W_{i-1}\cdots W_{l}
\end{aligned}
$$
边界为 $P_{[i,i+1)}=s_iW_i$。

有转移：

$$
\begin{aligned}
P_{[l,r)}&=P_{[l,m)}P_{[m,r)}\\
Q_{[l,r)}&=Q_{[l,m)}+Q_{[m,r)}P_{[l,m)}
\end{aligned}
$$

注意矩阵乘法不满足交换律，故转移中的乘法顺序必须严格考虑。

将该算法转置即可。

矩阵乘法的转置相当于用转置乘法计算转置后矩阵的乘法。

将输入塞在原来答案的位置，输出就会出现在原来输入的位置。

复杂度为 $O(k\log^2k+n\log^2n)$ ，常数较大。

