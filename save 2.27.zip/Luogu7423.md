﻿---
title: Luogu7423 「PMOI-2」简单构造题
date: 2025-02-25 14:41:56
tags: [多项式计数]
categories:
  - [算法竞赛, 题, 洛谷]
---

**题意**：定义一个长度为 $n$ 的序列 $A$ 的权值为：
$$
\sum_{l=1}^n\sum_{r=l}^n f_A(l,r)
$$
其中 $f_A(l,r)$ 是在 $A$ 的区间 $[l,r]$ 中，「所有**在该区间内出现过的**元素出现次数的乘积」再乘上「区间内所有元素的乘积」。 

对于所有长度为 $n$ 的，值域为 $[1,m]∩Z$ 的序列，求权值的期望。

答案对 $998244353$ 取模，$n\leq 2\times 10^5$，$m\leq 10^8$，时限 $\texttt{2s}$。

<!-- more -->

------------

对于长度为 $i$ 的区间，有 $n-i+1$ 个可能的位置，其余元素的方案数为 $m^{n-i}$。故贡献系数为 $(n-i+1)m^{n-i}$。

故只需对每个长度求出 $f$ 函数的期望。

若数字 $k$ 出现了 $c$ 次，则贡献为 $ck^c$。

写出数字 $k$ 的 EGF：

$$
F_k(x)=1+\sum\limits_{i=1}\dfrac{ik^ix^i}{i!}=1+kxe^{kx}
$$
这里使用 EGF 是为了将幂转化为封闭形式。

将各个数字的 EGF 相乘即可得到最终答案：

$$
G(x)=\prod_{k=1}^mF_k(x)=\prod_{k=1}^m\Big(1+kxe^{kx}\Big)
$$
注意到 $F_k(x)=F_1(kx)$，于是 

$$
\begin{aligned}
G(x)&=\prod_{k=1}^mF(kx)\\
&=\exp\sum_{k=1}^m\ln F(kx)\\
&=\exp\sum_{k=1}^m\sum\limits_{i=1}\Big([x^i]\ln F(x)\Big)k^i\\
&=\exp\sum\limits_{i=1}\Big([x^i]\ln F(x)\Big)\sum_{k=1}^mk^i\\
\end{aligned}
$$

于是只需 $\ln F(x)$ 和 $1\sim n$ 次的自然数幂和。

$$
H(x)=\sum\limits_{i=0}\dfrac{x^i}{i!}\sum\limits_{k=0}^mk^i=\sum\limits_{k=0}^m\sum\limits_{i=0}\dfrac{x^ik^i}{i!}=\sum\limits_{k=0}^me^{ki}=\dfrac{1-e^{(m+1)x}}{1-e^x}
$$
总复杂度 $O(n\log n)$。

