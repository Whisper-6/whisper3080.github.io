﻿---
title: AGC013E Placing Squares
date: 2025-02-25 10:06:39
tags: [动态规划]
categories:
  - [算法竞赛, 题, AtCoder]
---

**题意**：给定一条长为 $n$ 的线段，线段上有 $m$ 个标记点。

将线段切分为若干段，每一段的长度都要是整数，且不能切在标记点上。

设切为 $m$ 段，且第 $i$ 段的长度为 $l_i$，则这种切分的权值为 $\prod_{i=1}^ml_i^2$。

求所有合法切分的权值和。答案对 $10^9+7$ 取模。

$n\leq 10^9$，$m\leq 10^5$，时限 $\texttt{3s}$。

<!-- more -->

------------

考虑 $\rm DP$。

记 $f[i]$ 为切分 $[0,i]$ 的所有合法方案的权值。

当 $i$ 为标记点， $f[i]=0$。

否则，则有转移

$$
\begin{aligned}
f[i+1]&=\sum\limits_{j=0}^{i}(i+1-j)^2f[j]\\
&=\sum\limits_{j=0}^{i}\Big((i-j)^2+2(i-j)+1\Big)+f[j]\\
&=\sum\limits_{j=0}^{i}(i-j)^2f[j]+\sum\limits_{j=0}^{i}2(i-j)f[j]+\sum\limits_{j=0}^{i}f[j]
\end{aligned}
$$

于是，维护

$$
\begin{aligned}
s_0[i]&=\sum\limits_{j=0}^{i-1}f[j]\\
s_1[i]&=\sum\limits_{j=0}^{i-1}(i-j)f[j]\\
s_2[i]&=\sum\limits_{j=0}^{i-1}(i-j)^2f[j]
\end{aligned}
$$

则有 

$$
\begin{aligned}
f[i]&=s_2[i]\\
s_0[i+1]&=s_0[i]+f[i]=s_2[i]+s_0[i]\\
s_1[i+1]&=\sum\limits_{j=0}^i(i+1-j)f[j]=\sum\limits_{j=0}^{i-1}(i-j)f[j]+\sum\limits_{j=0}^{i}f[j]=s_2[i]+s_1[i]+s_0[i]\\
s_2[i+1]&=f[i+1]=s_2[i]+2s_1[i]+s_0[i+1]=2s_2[i]+2s_1[i]+s_0[i+1]\\
\end{aligned}
$$

当 $i$ 为标记点，有

$$
\begin{aligned}
s_2[i+1]&=s_2[i]+2s_1[i]+s_0[i]\\
s_0[i+1]&=s_0[i]\\
s_1[i+1]&=s_1[i]+s_0[i]\\
\end{aligned}
$$

上述转移不难用矩阵描述，使用矩阵快速幂，即可做到 $O(m\log n)$。

