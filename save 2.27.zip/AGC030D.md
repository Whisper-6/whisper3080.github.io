﻿---
title: AGC030D Inversion Sum
date: 2025-02-25 14:25:46
tags: [动态规划, 思维]
categories:
  - [算法竞赛, 题, AtCoder]
---

**题意**：给你一个长度为 $n$ 的数列 $A$，然后给出 $q$ 个交换操作。

设交换操作序列 $S$ 按顺序使用后，$A$ 中逆序对的个数为 $F(S)$。

枚举 $q$ 个操作的 $2^{|q|}$ 个子集 $S$，求 $f(S)$ 的总和。

答案对 $10^9+7$ 取模，$n,q\leq 3000$，时限 $\texttt{3s}$。

<!-- more -->

------------

$n$ 较小，允许我们考虑每个（可能产生逆序对的）二元组。

维护 $f_k(i,j)$ 表示考虑完前 $k$ 个操作后， $A_i<A_j$ 的情况数。

若不执行第 $k$ 步交换，则有 $f_k(i,j)\leftarrow f_{k-1}(i,j)$

若执行第 $k$ 步交换 $(x,y)$：

$$
\begin{aligned}
f_k(x,y)&\leftarrow f_{k-1}(y,x)\\
f_k(x,i)&\leftarrow f_{k-1}(y,i)&(i\neq y)\\
f_k(i,x)&\leftarrow f_{k-1}(i,y)&(i\neq y)\\
f_k(y,i)&\leftarrow f_{k-1}(x,i)&(i\neq x)\\
f_k(i,y)&\leftarrow f_{k-1}(i,x)&(i\neq x)\\
f_k(i,j)&\leftarrow f_{k-1}(i,j)&(i\neq x,j\neq y)\\
\end{aligned}
$$

其中，前五条所影响的状态量是 $O(n)$ 的。最后一条的效果是让某个位置乘以 $2$，可以利用时间戳懒处理，或转为维护期望。

最后对于所有 $i>j$ 的 $f_q(i,j)$ 求和即可得到答案。

复杂度 $O\big(n(n+q)\big)$。

