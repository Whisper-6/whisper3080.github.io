﻿---
title: ARC078D Mole and Abandoned Mine
date: 2025-02-22 22:13:54
tags: [动态规划, 图论]
categories:
  - [算法竞赛, 题, AtCoder]
---

**题意**：给一个 $n$ 个点 $m$ 条边的无向连通简单图，边有边权。

要求割掉若干条边，使 $1$ 到 $n$ 只有一条简单路径，问割掉的边权和最小是多少。

$n\leq 15$，时限 $\texttt{4s}$。

<!-- more -->

------------

取反后可以转化为：保留一个边集使 $1$ 到 $n$ 只有一条简单路径，且边权和最大。

观察符合题意的图会长什么样，如下图：

![](ARC078D\1.png)

会有很多子图挂在 $1\leftrightarrow n$ 的那条唯一的简单路径上，挂在两个不同点上的子图不能连通（如图中蓝边），否则不合法。

考虑状压 $\rm DP$ ，每次向链上加入一个点以及其挂着的子图。

记 $dp[S,t]$ 表示已经考虑了集合 $S$ 内的点，链的末尾为 $t$ 的最优解。

记 $w(u,v)$ 为 $u,v$ 之间的边权（若边不存在则为 $-\infty$ ）， $W(S)$ 为集合 $S$ 内部的边权和。

则有转移：

$$
\begin{aligned}
dp[S+\{u\},u]&\gets dp[S,t]+w(t,u)\quad(u\notin S)\\
dp[S+T,t]&\leftarrow dp[S,t]+W(T+\{t\})\quad(S∩T=\varnothing)
\end{aligned}
$$
分别对应“将链延长”与“挂一个子图在当前端点上”。

复杂度 $O(3^nn)$。

