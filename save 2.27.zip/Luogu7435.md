﻿---
title: Luogu7435 简单的排列计数
date: 2025-02-25 14:09:06
tags: [多项式计数]
categories:
  - [算法竞赛, 题, 洛谷]
---

**题意** : 设 $\text{inv}_{p}$ 表示排列 $p$ 的逆序对数。如果 $p$ 长度为 $n$ 则有
$$
\text{inv}_{p}=\sum\limits_{i=1}^{n}\sum\limits_{j=i+1}^{n}[p_i>p_j]
$$
给定两个正整数 $n,k$，和一个排列 $p^\prime$，定义一个长度为 $n$ 的排列 $p$ 的权值 $\text{val}_{p}$ 为

$$
\text{val}_{p}=\prod\limits_{i=1}^{n}\prod_{j=i+1}^{n}p_i^{[p_{i}>p_j]}
$$
对于 $0\leq m\leq k$ 求

$$
\sum\limits_{p}[\text{inv}_p=m]\text{val}_p
$$
其中 $p$ 是长度为 $n$ 的排列。

$n,k\leq 2\times 10^5$，时限 $\texttt{0.9s}$。

<!-- more -->

------------

对于排列 $p$ ，定义 $t_i=\sum\limits_{j=i+1}^{n}[p_i>p_j]$ ，即 $i$ 与后方元素的逆序对数。

可以证明， $\{t_i\}$ 和 $\{p_i\}$ 构成一一对应。

设 $p'_i$ 为 $p_i$ 的逆排列，则$\{t_{p_i'}\}$ 也和 $\{p_i\}$ 构成一一对应。

$$
\text{val}_{p}=\prod\limits_{i=1}^{n}\prod_{j=i+1}^{n}p_i^{[p_{i}>p_j]}=\prod\limits_{i=1}^{n}p_i^{t_i}=\prod\limits_{i=1}^{n}i^{t_{p_i'}}
$$
记 $o_i=t_{p_i'}$ ，组合意义是 ：值 $i$ 后方的逆序对数。

有（充要）约束  ： $0\leq o_i<i$。

故答案的生成函数为 ：

$$
\sum_{o}\sum\limits_{i=1}^n(xi)^{o_i}=\prod_{i=1}^n\dfrac{1-i^ix^i}{1-ix}
$$
考虑分子分母分别计算。使用 $\ln + \exp$ :

分子：

$$
\begin{aligned}
P(x)&=\prod_{i=1}^n1-i^ix^i\\
&=\exp\sum_{i=1}^n\ln(1-i^ix^i)\\
&=\exp\sum_{i=1}^n-\sum\limits_{j=1}\dfrac{(ix)^{ij}}{j}\\
\end{aligned}
$$

暴力求和即是 $O(n\log n)$ 的，注意要避免在复杂度瓶颈上直接快速幂。

分母：

$$
\begin{aligned}
Q(x)&=\prod_{i=1}^n(1-ix)\\
&=\exp\sum_{i=1}^n\ln(1-ix)\\
&=\exp\sum_{i=1}^n\sum\limits_{j=1}-\dfrac{(ix)^j}{j}\\
&=\exp-\sum\limits_{j=1}\dfrac{x^j}{j}\sum_{i=1}^ni^j
\end{aligned}
$$

即求出 $1\sim n$ 的 $1\sim n$ 次方和。

$$
H(x)=\sum\limits_{i=0}\dfrac{x^i}{i!}\sum\limits_{k=0}^nk^i=\sum\limits_{k=0}^n\sum\limits_{i=0}\dfrac{x^ik^i}{i!}=\sum\limits_{k=0}^ne^{ki}=\dfrac{1-e^{(n+1)x}}{1-e^x}
$$
实现时注意将分子分母相减再 $\exp$ ，不要分别 $\exp$。

复杂度 $O(n\log n)$ ，注意常数。

