---
title: Luogu4827 [国家集训队] Crash 的文明世界
date: 2025-02-27 16:04:02
tags: [组合数学, 动态规划]
categories:
  - [算法竞赛, 题, 洛谷]
---

**题意**：给出 $n$ 个点的树 $T$，对于每个点 $u$，求
$$
S(u)=\sum_{v\in T}dis^k(u,v)
$$
答案对 $10007$ 取模，$n\leq 5\times 10^4$，$k\leq 150$，时限 $\texttt{1s}$。

<!-- more -->

-----

$k≤150$ 允许我们用第二类斯特林把 $k$ 次方拆成组合数，后者有更好的组合性质。
$$
\begin{aligned}
S(u)
&=\sum_{v}\sum_{j=0}^k
\dbinom{dis(u,v)}{j}j!\begin{Bmatrix}k\\j\end{Bmatrix}\\
&=\sum_{j=0}^k
\begin{Bmatrix}k\\j\end{Bmatrix}j!
\sum_{v}\dbinom{dis(u,v)}{j}\\
\end{aligned}
$$
于是，我们只需对于每个 $u,j$ 求出
$$
G(u,j)=\sum_{v}\dbinom{dis(u,v)}{j}
$$

-----

先考虑如何对根求解。使用树形 DP，记
$$
F[u][j]:=\sum_{v\text{在}u\text{的子树内}}\binom{dis(u,v)}{j}
$$
转移时，儿子 $t$ 对 $u$ 贡献，对于 $t$ 子树中的 $v$，有 $dis(u,v)=dis(t,v)+1$，即
$$
\begin{aligned}
F[u][j]&\gets\sum_{v\text{在}t\text{的子树内}}\binom{dis(u,v)}{j}\\
&=\sum_{v\text{在}t\text{的子树内}}\binom{dis(t,v)+1}{j}\\
&=\sum_{v\text{在}t\text{的子树内}}\left[\binom{dis(t,v)}{j}+\binom{dis(t,v)}{j-1}\right]\\
&=F[t][j]+F[t][j-1]\\
\end{aligned}
$$
综上：
$$
F[u][j]=\sum_{t\text{是}u\text{的儿子}}F[t][j]+F[t][j-1]
$$
特殊地，$F[u][0]=siz_u$。

复杂度 $O(nk)$。这样可以得出根的答案。

换根 DP 即可得到所有点的答案。转移的逆操作很简单，把加号改成减号就好。
