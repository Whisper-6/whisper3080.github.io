﻿---
title: Luogu6694 强迫症
date: 2025-02-27 01:32:14
tags: [多项式]
mathjax: true
categories:
  - [算法竞赛, 题, 洛谷]
---

**题意**：在一个圆上有 $n$ 个点，现在要以某种方式在其间连边，任意两条边不能相交。

第 $i$ 个点有权值 $a_i$，一条 $(u,v)$ 之间的边权值为 $a_ia_j$。

一种连边方式的权值定义为所有边的权值和。

求连边方式的期望权值。答案对 $998244353$ 取模。

$n\leq 10^5$，$a\leq 10^6$，时限 $\texttt{2s}$。

<!-- more -->

------------

设 $G[n]$ 为 $n$ 个点的环连边不相交的方案数。

设 $G_*[n]$ 为 $n$ 个点的环,已经连边 $(1,n)$ 后连边不相交的方案数。

不难发现，含有 $(1,n)$ 的图和不含 $(1,n)$ 的图之间存在一一对应，则有 $G_*[n]=\frac{1}{2}G[n]$。

分别考虑每条边 $(i,j)$ 的贡献，答案为:

$$
{\rm Ans}=\dfrac{1}{G[n]}\sum\limits_{i=1}^n\sum\limits_{j=i+1}^na_ia_j\dfrac{G[j-i+1]G[n-j+i+1]}{4}
$$
连边 $(i,j)$ 后，将整个图划分成了两个子问题，方案数为 $G_*[j-i+1]$ 和 $G_*[n-j+i+1]$。

令 $B[k]=\frac{1}{4}G[k+1]G[n-k+1]$，则：
$$
\begin{aligned}
{\rm Ans}=&=\dfrac{1}{G[n]}\sum\limits_{i=1}^n\sum\limits_{j=i+1}^na_ia_jB[j-i]\\
&=\dfrac{1}{G[n]}\sum\limits_{t=0}^nB[t]\sum\limits_{i=0}^na_ia_{i+t}
\end{aligned}
$$
可以差卷积计算。

-----

问题转化为求出 $G$。考虑递推。

若 $n$ 号点没有连边，则方案数显然为 $G[n-1]$。

否则，枚举其第一条边 $(i,n)$。

在前面不会有其它与 $n$ 相连的边，方案数为 $G[i]$。

在后面相当于边上已经连了一条边，方案数为 $G_*[n-i+1]=\dfrac{1}{2}G[n-i+1]$。

则有
$$
\begin{aligned}
G[n]&=G[n-1]+\dfrac{1}{2}\sum\limits_{i=1}^{n-1}G[i]G[n-i+1]\\
3G[n]&=2G[n-1]+\sum\limits_{i=0}^{n+1}G[i]G[n+1-i]\\
3G[n]&=2G[n-1]+G^2[n+1]\\
3xG(x)&=2x^2G(x)+G(x)^2+2x^2
\end{aligned}
$$
解得
$$
G(x)=\dfrac{2x^2-3x±x\sqrt{4x^2-12x+1}}{2}=x\dfrac{2x-3±\sqrt{4x^2-12x+1}}{2}
$$
根据 $G[1]=1$ 检验，发现取负号符合要求。

问题只剩如何计算 $F(x)=\sqrt{4x^2-12x+1}$ 的各项系数。

使用小多项式快速幂即可。

复杂度 $O(n\log n)$。

