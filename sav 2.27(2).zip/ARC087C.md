﻿---
title: ARC087C Prefix-free Game
date: 2025-02-23 19:05:27
tags: [博弈论]
categories:
  - [算法竞赛, 题, AtCoder]
---

**题意**：本题中，字符集为 $\{\texttt{0},\texttt{1}\}$。

给出 $L$，定义一个字符串集合 $S$ 是好的，当且仅当 ：

- $S$ 中的字符串长度在 $1\sim L$ 之间。

- $S$ 中的任意两个字符串，都不能满足一者为另一者的前缀。

给出一个好的字符串集合 $S$。

A 和 B 博弈。两人轮流操作，每次可以向 $S$ 中加入一个字符串，无法操作者输。

问是否先手必胜。

$n\leq 10^5$，时限 $\texttt{2s}$。

<!-- more -->

------------

我们先用 $S$ 内的字符串建立字典树。

那么，每个串的前缀和子树都不能再选择，剩下的区域均为满二叉树。

考虑使用 $\rm SG$ 函数。

记层数为 $h$ 的满二叉树的 $\rm SG$ 值为 $f[h]$。

利用 $\text{Muti-SG}$ 的分析技巧，不难列出递推式 ：

$$
\begin{aligned}
f[h]=&{\rm mex}\Big\{\\
&0,\\
&f[h-1],\\
&f[h-1]\oplus f[h-2],\\
&f[h-1]\oplus f[h-2]\oplus f[h-3]\\
&\cdots\\
&f[h-1]\oplus f[h-2]\oplus ... \oplus f[1]\\
\Big\}&\\
\end{aligned}
$$

打表可以发现 $f[h]={\rm lowbit}(h)$。


