---
title: Luogu2791 幼儿园篮球题
date: 2025-02-27 17:36:17
tags: [组合数学, 多项式]
categories:
  - [算法竞赛, 题, 洛谷]
---

**题意**：$T$ 组询问，每组给出 $n,m,k$，求：

$$
\dbinom{n}{k}^{-1}\sum\limits_{i=0}^{k}\dbinom{m}{i}\dbinom{n-m}{k-i}i^L
$$
其中 $L$ 是全局常数。

$T\leq 200$，$L\leq 2\times10^5$，$n,m\leq 2\times10^7$，时限 $\texttt{2s}$。

<!-- more -->

------------

前面常数先忽略。

无法使用二项式定理，且 $L$ 较小，尝试用第二类斯特林数将幂 $i^L$ 展开为组合数。
$$
\begin{aligned}
\sum_{i=0}^k
\dbinom{m}{i}\dbinom{n-m}{k-i}i^L
&=\sum_{i=0}^k
\dbinom{m}{i}\dbinom{n-m}{k-i}
\sum_{j=0}^i
\dbinom{i}{j}j!\begin{Bmatrix}L\\j\end{Bmatrix}\\
&=\sum_{j=0}^k
j!\begin{Bmatrix}L\\j\end{Bmatrix}
\sum_{i=j}^k
\dbinom{m}{i}\dbinom{n-m}{k-i}\dbinom{i}{j}
\end{aligned}
$$
后面三个组合数一脸不可做……直接暴力拆开消消看:
$$
=\sum_{j=0}^k
j!\begin{Bmatrix}L\\j\end{Bmatrix}
\sum_{i=j}^k
\dfrac{m!}{i!(m-i)!}
\dfrac{n!}{(k-i)!(n-k+i)!}
\dfrac{i!}{j!(i-j)!}\\
$$
我一消
$$
=\sum_{j=0}^k
\begin{Bmatrix}L\\j\end{Bmatrix}
\sum_{i=j}^k
\dfrac{m!n!}{(m-i)!(k-i)!(n-k+i)!(i-j)!}\\
$$
再给补上一些东西变回组合数。理论上补任意不和 $i$ 有关的东西都行。
$$
=\sum_{j=0}^k\dfrac{m!}{(m-j)!}\begin{Bmatrix}L\\j\end{Bmatrix}\sum_{i=j}^{k}\dfrac{(m-j)!}{(m-i)!(i-j)!}\dfrac{n!}{(k-i)!(n-k+i)!}
$$
我一合（这回只剩两个组合数了）
$$
\begin{aligned}
&=
\sum_{j=0}^k
\dfrac{m!}{(m-j)!}
\begin{Bmatrix}L\\j\end{Bmatrix}
\sum_{i=j}^k
\dbinom{m-j}{i-j}\dbinom{n-m}{k-i}\\
&=
\sum_{j=0}^k
\dfrac{m!}{(m-j)!}
\begin{Bmatrix}L\\j\end{Bmatrix}\,
\boxed{\sum_{i=0}^{k-j}
\dbinom{m-j}{i}\dbinom{n-m}{k-j-i}}\\
\end{aligned}
$$
辨认出范德蒙德卷积
$$
\begin{aligned}
&=
\sum_{j=0}^k
\dfrac{m!}{(m-j)!}
\begin{Bmatrix}L\\j\end{Bmatrix}
\dbinom{n-j}{k-j}
\end{aligned}
$$
预处理出 $L$ 以内的一行第二类斯特林数，就可以每次 $O(L)$ 求了。

复杂度 $O(L\log L+N+SL)$。
