﻿---
title: Luogu6778 [Ynoi2009] rpdq
date: 2025-02-20 20:31:18
tags: [数据结构]
categories:
  - [算法竞赛, 题, 洛谷]
---

**题意**：给定一棵 $n$ 个点的树，边有边权。

每次询问给出 $l,r$，求：

$$
\sum\limits_{l\leq u<v\leq r}dis(u,v)
$$
答案对 $2^{32}$ 取模。

允许离线， $n,q\leq 2\times 10^5$，时限 $\texttt{4s}$，空限 $\texttt{1Gb}$。

<!-- more -->

------------

本题解无 $\text{top cluster}$ 树分块，请放心食用。（迫真）

- 前置芝士

  - 二次离线莫队：[Luogu5047 [Ynoi2019 模拟赛] Yuno loves sqrt technology II](https://www.luogu.com.cn/problem/P5047)

  - 经典问题：[Luogu4211 [LNOI2014]LCA](https://www.luogu.com.cn/problem/P4211)

使用**二次离线莫队**。

容易将问题转化为 $O(n\sqrt{m})$ 次

$$
\begin{aligned}
\sum\limits_{v\leq r}dis(u,v)=r\times dep_u+\sum\limits_{v\leq r}dep_v-2\sum\limits_{v\leq r}dep_{ {\rm lca}(u,v) }
\end{aligned}
$$

的求解。

难点在于 $\sum\limits_{v\leq r}dep_{ {\rm lca}(u,v) }$，这是 “经典问题”，将点 $1\sim r$ 到根的点权加上父边边权，然后查询 $u$ 到根的路径和即可得到。

问题转化为 $O(n)$ 次路径加与 $O(n\sqrt{m})$ 次路径求和。

然后我们尴尬地发现，常用的树上数据结构几乎全部带 $\log$，不能很好地平衡复杂度。

-----

考虑**树分块**。

每个点只归属于一个块，每个块形成一个树上联通块。**记块中的最浅点为关键点。**

接下来是分块方法。

若 $siz_u\leq \sqrt{n}$ 且 $siz_{fa}>\sqrt{n}$，则将 $u$ 的子树分成一块。（第一类）

这样还剩了所有子树大小 $>\sqrt{n}$ 的点没有归属，这些点构成一棵分叉为 $O(\sqrt{n})$ 的树。

对于每条**不分叉**的链条，尽量按照 $\sqrt{n}$ 划分，如果最后剩下一小段不足 $\sqrt{n}$，也直接分成一块。（第二类）

![](Luogu6778\1.png)

第二类块的个数为 $O(\sqrt{n})$，形态为**一条链**。

第一类块的个数不限，形态为一棵子树。一类块下面不再有块，一类块上面一定是二类块。

记 $f_u$ 为 $u$ 的父亲，$b_u$ 为 $u$ 所在块的关键点。

- 对 $u$ 进行链加

  记 $w_u$ 表示 $u$ 到关键点的路径的和。

  若 $u$ 在一类块中，暴力 $\rm dfs$ 整块更新 $w$，然后修改 $f_{b_u}$，则转化为 $u$ 在二类块中的情况。

  若 $u$ 在二类块中，仍然先暴力 $\rm dfs$ 整块更新 $w$ 。

  $u$ 还会对祖先块的 $w$ 进行贡献。注意到由于二类块形态是一条链，一定是整个块都加，只需要记下整块标记。

  对于**二类块**的关键点，维护到根的路径的和，由于二类块的个数较少，可以每次修改后暴力 $\rm dfs$ 计算。

- 对 $u$ 进行链查询

  若 $u$ 在一类块中，答案加上 $w_u$，然后查询 $f_{b_u}$，则转化为 $u$ 在二类块中的情况。

  若 $u$ 在二类块中，答案为 $tag_{b_u}\times td_u+w_u+w'_{b_u}$

  其中 $tag_{b_u}$ 表示块 $b_u$ 被整体加的次数， $td_u$ 表示 $u$ 到关键点的距离， $w'_{b_u}$ 表示关键点 $b_u$ 到根的路径和。


时间复杂度 $O\big(n(\sqrt{n}+\sqrt{m})\big)$，空间复杂度 $O(n)$。


