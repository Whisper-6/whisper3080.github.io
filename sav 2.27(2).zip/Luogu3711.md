---
title: Luogu3711 仓鼠的数学题
date: 2025-02-27 17:56:10
tags: [多项式]
categories:
  - [算法竞赛, 题, 洛谷]
---

**题意**：设
$$
S_k(x)=\sum_{i=0}^xi^k
$$
为自然数 $k$ 次幂和的多项式。

给出 $A[0\sim n]$，求多项式
$$
F(x)=\sum_{k=0}^nA[k]S_k(x)
$$
的各项系数。

答案对 $998244353$ 取模，$n\leq 2.5\times10^5$，时限 $\texttt{1s}$。

<!-- more -->

------------

令 $B(x)=\dfrac{x}{e^x-1}$，根据伯努利数的结论
$$
\begin{aligned}
S_k(x)&=
x^k+
k!\sum_{i=0}^k
\dfrac{B[k-i]x^{i+1}}{(i+1)!}
\\
F(x)&=
\sum_{k=0}^n A[k] \left(
	x^k+
	k!\sum_{i=0}^{k}
	\dfrac{B[k-i]x^{i+1}}{(i+1)!}
\right)
\\
&=
\sum_{k=0}^nA[k]x^k+
\sum_{k=0}^n
A[k]k!
\sum_{i=0}^{k}
\dfrac{B[k-i]x^{i+1}}{(i+1)!}

\end{aligned}
$$
左侧一小部分最后单独累加即可，暂时略去。

对于右侧，交换和式可得：
$$
\sum_{k=0}^n
A[k]k!
\sum_{i=0}^k
\dfrac{B[k-i]x^{i+1}}{(i+1)!}
=
\sum_{i=0}^n
x^{i+1}
\sum_{k=i}^n
\dfrac{B[k-i]}{(i+1)!}A[k]k!
$$
这意味着

$$
F[i+1]\gets\dfrac{1}{(i+1)!}\sum_{k=i}^nB[k-i]A[k]k!
$$
差卷积即可。

复杂度 $O(n\log n)$。
