﻿---
title: Luogu5326 [ZJOI2019] 开关
date: 2025-02-25 13:56:51
tags: [多项式]
categories:
  - [算法竞赛, 题, 洛谷]
---

**题意**：有 $n$ 个开关，每个开关有 $0/1$ 两种状态，初始状态为 $0$。

对某个开关进行操作可以使得其状态改变，由 $0$ 变为 $1$ 或由 $1$ 变为 $0$。

每个开关都有目标状态，记 $s_i$ 为第 $i$ 个开关的目标状态，当所有开关都达到目标状态，任务达成。

操作按照一定规则随机，具体地，第 $i$ 个开关有权值 $w_i$ ，随机到的概率即为 $\dfrac{w_i}{\sum_{k=1}^nw_k}$。

求按上述规则随机操作时，完成任务所需的期望操作次数。

答案对 $998244353$ 取模，$n\leq 100$，$\sum w\leq 5\times 10^4$，时限 $\texttt{1s}$。

<!-- more -->

------------

题目中“一达成目标就停止”的要求是经典的，考虑 PGF。

设 $f_k$ 为在 $k$ 次操作后达成目标的概率，对应的概率生成函数为 $F(x)$。

设 $g_k$ 为在 $k$ 次操作后回到原状态的概率，对应的概率生成函数为 $G(x)$。

设 $h_k$ 为在 $k$ 次操作后第一次达成目标的概率，对应的概率生成函数为 $H(x)$。

只有 $H(x)$ 才是一个标准的 PGF，满足 $H(1)=1$，而 $H'(1)$ 也正是答案。

根据 xor 的良好性质，对于一种在第 $k$ 步达成目标的情况，肯定是之前某处（或这一步）已经达成过，然后经过若干步又回到达成状态，故
$$G(x)H(x)=F(x)\Rightarrow H(x)=\dfrac{F(x)}{G(x)}$$

于是，我们只需设法得到 $F(x),G(x)$。

记 $p_i=\frac{w_i}{\sum_{k=1}^nw_k}$。

将我们每一轮按下的开关写成一个序列，称作“操作序列”。

记 $c_i$ 表示操作序列中 $i$ 出现的次数，当 $c_i\bmod 2=s_i$ 时，开关 $i$ 此时在目标状态。

于是，对开关 $i$ 构造 EGF
$$
\hat F_i(x)=\sum\limits_{k=1}[k\bmod 2=s_i]p_i^k\dfrac{x^k}{k!}
$$

计算 $\hat F(x)=\prod\limits_{i=1}^nF_i(x)$，$\big[\frac{x^k}{k!}\big]\hat F(x)$ 即为在 $k$ 次操作后达成目标的概率。

设 $\big[\frac{x^k}{k!}\big]\hat G(x)$ 为用 $k$ 次操作回到原状态的概率，等价于所有 $s=0$ 时的 $F$。

不难写出 

$$
\begin{aligned}
\hat F_i(x)&=\dfrac{e^{p_ix}+(-1)^{s_i}e^{-p_ix}}{2}\\
\hat F(x)&=\prod\limits_{i=1}^n\dfrac{e^{p_ix}+(-1)^{s_i}e^{-p_ix}}{2}\\
\hat G(x)&=\prod\limits_{i=1}^n\dfrac{e^{p_ix}+e^{-p_ix}}{2}
\end{aligned}
$$

但此处是 EGF，需要转化为 OGF。考虑将 $e^{cx}$ 作为基本单位，最后将其线性组合转化为 OGF。（类似于对 OGF 的分式分解）

具体地，$e^{cx}$ 被转化为 $\dfrac{1}{1-cx}$，它们对应的数列都是 $\langle 1,c,c^2,\cdots\rangle$。

将某 EGF 表示为 $\sum\limits_{c}a_ce^{cx}$ 的形式，其中 $a_c$ 是系数。

由于本题的特殊性，$\hat F,\hat G$ 均可以这样表示，且 $c$ 的值只有较少的 $O(\sum w)$ 个。

暴力卷积即可 $O(n\sum w)$ 地求出 $F,G$ 的表示，即

$$
\begin{aligned}
\hat F(x)&=\sum\limits_{c}f_ce^{cx}\\
\hat G(x)&=\sum\limits_{c}g_ce^{cx}
\end{aligned}
$$

然后将其转为系数对应的 OGF。

$$
\begin{aligned}
F(x)&=\sum\limits_{c}\dfrac{f_c}{1-cx}\\
G(x)&=\sum\limits_{c}\dfrac{g_c}{1-cx}\\
H(x)&=F(x)/G(x)\\
H'(1)&=\dfrac{F'(1)G(1)-G'(1)F(1)}{G(1)^2}
\end{aligned}
$$

于是我们只需求出 $F(1),G(1),F'(1),G'(1)$。

$\frac{1}{1-cx}$ 的系数是等比数列 $\{1,c,c^2,c^3...\}$，其系数和即为 $\dfrac{1}{1-c}$。

但这只在 $|c|<1$ 时成立，我们的表示中存在着不收敛的 $\frac{1}{1-x}$ 项，故要预先乘以 $1-x$ 以避免这种情况。

$$
\begin{aligned}
F_2(x)&=(1-x)\sum\limits_{c}\dfrac{f_c}{1-cx}=f_1+\sum\limits_{c\neq 1}\dfrac{f_c(1-x)}{1-cx}\\
G_2(x)&=(1-x)\sum\limits_{c}\dfrac{g_c}{1-cx}=g_1+\sum\limits_{c\neq 1}\dfrac{g_c(1-x)}{1-cx}\\
H(x)&=F_2(x)/G_2(x)\\
H'(1)&=\dfrac{F_2'(1)G_2(1)-G_2'(1)F_2(1)}{G_2(1)^2}
\end{aligned}
$$

于是我们只需求出 $F_2(1),G_2(1),F_2'(1),G_2'(1)$。

显然有 $F_2(1)=f_1,G_2(1)=g_1$。

$\big(\frac{1-x}{1-cx}\big)'$ 的系数对应数列 $\{c-c^2,2(c^2-c^3),3(c^3-c^4),...\}$，系数和为 
$$
\sum\limits_{i=1}^{+\infty}i(c^i-c^{i+1})=(1-c)\sum\limits_{i=1}ic^i=\dfrac{1}{c-1}
$$

由此不难求出 $F_2'(1),G_2'(1)$。


