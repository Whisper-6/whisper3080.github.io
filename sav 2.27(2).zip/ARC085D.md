﻿---
title: ARC085D NRE
date: 2025-02-23 20:45:42
tags: [动态规划, 数据结构]
categories:
  - [算法竞赛, 题, AtCoder]
---

**题意**：给定长为 $n$ 的 $01$ 数组 $b$ 。

有一个长度同为 $n$ 的数组 $A$，初始时为全 $0$。

给定 $m$ 个区间，可以选择若干区间，将 $a$ 中区间内的元素置为 $1$。

最小化 $\sum\limits_{i=1}^n[A_i\neq B_i]$ 的值。

$n\leq 2\times 10^5$，时限 $\texttt{3s}$。

<!-- more -->

------------

注意到 $A,B$ 均为 $01$ 数组，则 

$$
\begin{aligned}
&[A_i\neq B_i]\\
=&[A_i=0][B_i=1]+[A_i=1][B_i=0]\\
=&[A_i=0][B_i=1]+[B_i=0]-[A_i=0][B_i=0]\\
\end{aligned}
$$

此时不需要考虑 $A_i=1$ 的贡献。

> 只有 $01\ \rightarrow$ 正难则反

其中 $[B_i=0]$ 是定值，于是我们只需最小化： 

$$
\sum\limits_{i=1}^n[A_i=0][B_i=1]-[A_i=0][B_i=0]
$$
考虑 $\rm DP$，记 $f[i][j]$ 表示考虑了所有 $l\leq i$ 的区间，最右覆盖到 $j$， $[1,i]$ 的贡献最小值。

特殊地，若没有向右覆盖，则 $j$ 记为 $i$ 。

从 $f[i-1][\_]$ 转移至 $f[i][\_]$ 时 ：

- 不选区间：
  $$
  \begin{aligned}
  f[i][i]&\leftarrow f[i-1][i-1]+[B_i=1]-[B_i=0]\\
  f[i][j]&\leftarrow f[i-1][j]\quad(j\geq i)
  \end{aligned}
  $$

- 选择区间。枚举在 $i$ 开头的区间 $[i,r]$，有：
  $$
  f[i][r]\leftarrow f[i-1][i-1\sim r]
  $$

可以用线段树维护，复杂度为 $O(n\log n)$。


