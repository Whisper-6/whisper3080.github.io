﻿---
title: Luogu4062 [Code+#1] Yazid 的新生舞会
date: 2025-02-25 14:12:50
tags: [数据结构]
categories:
  - [算法竞赛, 题, 洛谷]
---

**题意**：对于序列 $A$，若有某个数的出现次数超过 $|A|/2$，则称之为好序列。

给出长度为 $n$ 的序列 $A$，问有多少个区间是好序列。

$n\leq 5\times 10^5$，时限 $\texttt{4s}$。

<!-- more -->

------------

将出现次数过半的数称为强众数。显然，某个序列若有强众数，则至多只有一个。

所以，可以枚举强众数 $w$，然后计算能贡献的区间。

构造新序列 $B_i=[A_i=w]$，令 $S$ 为 $B$ 的前缀和。

则区间 $(l,r]$ 的强众数为 $w$ 的充要条件是 ：

$$
2(S_r-S_l)>r-l\ \Leftrightarrow\ 2S_r-r>2S_l-l
$$
于是可以转化为二维偏序问题。

-----

但对每个 $w$ 做一次二维偏序显然无法通过。注意到 $B_i$ 中 $1$ 的个数总和是 $O(n)$ 的，考虑借助这一性质减小复杂度。

令 $C_i=2S_i-i$，在两个 $1$ 之间的大量连续 $0$ 中，$C_i$ 是一个公差为 $-1$ 的等差序列。

$$
\begin{matrix}
B:&0&0&1&0&0&0&1&0\\
C:&\!\!\!\big|-1&-2&\!\!\!\big|-1&-2&-3&-4&\!\!\!\big|-3&-4
\end{matrix}
$$

不难发现，按照 $1$ 划分，即可得到共 $O(n)$ 个等差序列。

于是，问题变为等差序列的偏序问题。

-----

显然，一条等差序列内部是没有偏序的，于是我们逐个插入等差序列，并计算与前面的等差序列之间的贡献。

记 $o[x]$ 为等于 $x$ 的数的个数，加入一个等差序列等价于区间加。

查询时，对于等差序列 $l\sim r$，贡献为 $\sum\limits_{i=l}^r\sum\limits_{j\leq i}o[j]$。可以差分为 $\sum\limits_{i\leq m}\sum\limits_{j\leq i}o[j]$ 状物。

再令 $o_2$ 为 $o$ 的差分，则问题变为 $\sum\limits_{i\leq m}\sum\limits_{j\leq i}\sum\limits_{k\leq j}o_2[k]$。即单点修改，查询三阶前缀和。
$$
\begin{aligned}
&\sum\limits_{i\leq m}\sum\limits_{j\leq i}\sum\limits_{k\leq j}o_2[k]\\
&=\sum\limits_{k\leq m}o_2[k]\sum\limits_{k\leq j\leq m}\sum\limits_{j\leq i\leq m}1\\
&=\sum\limits_{k\leq m}o_2[k]\dfrac{(m-k+2)(m-k+1)}{2}\\
&=\frac{1}{2}\bigg((m^2+3m+2)\sum\limits_{k\leq m}o_2[k]-(2m+3)\sum\limits_{k\leq m}o_2[k]k+\sum\limits_{k\leq m}o_2[k]k^2\bigg)
\end{aligned}
$$

树状数组分别维护 $o_2[k],\ o_2[k]k,\ o_2[k]k^2$ 的前缀和即可。

复杂度 $O(n\log n)$。


