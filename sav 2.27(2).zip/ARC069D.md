﻿---
title: ARC069D Flags
date: 2025-02-23 18:52:17
tags: [数据结构, 图论]
categories:
  - [算法竞赛, 题, AtCoder]
---

**题意** ： 将 $N$ 个标志放在数轴上。第 $i$ 个标志可以放置在坐标 $a_i$ 或 $b_i$ 上。

求出两个标志之间最小距离的最大值。

$n\leq 10^4$，时限 $\texttt{5s}$。

<!-- more -->

------------

先二分答案，然后用 $\text{2-sat}$ 判定。

枚举点标志 $i$，对于另标志 $j$，按如下规则连边。

- $|a_i-a_j|\leq mid$ : $a_i\rightarrow b_j$

- $|b_i-a_j|\leq mid$ : $b_i\rightarrow b_j$

- $|a_i-b_j|\leq mid$ : $a_i\rightarrow a_j$

- $|b_i-b_j|\leq mid$ : $b_i\rightarrow a_j$

缩点后，若 $a_i,b_i$ 在同一个联通块内，则无解。

不难用（两颗）线段树优化建边。复杂度为 $O(n\log^2 n)$。

常数大得有点离谱……


