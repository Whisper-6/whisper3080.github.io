﻿---
title: ARC084B Small Multiple
date: 2025-02-22 22:11:24
tags: [图论, 数论]
categories:
  - [算法竞赛, 题, AtCoder]
---

**题意** ： 给定整数 $k$。

求 $c\in \rm Z^+$，使得 $ck$ 在十进制下的数位和最小，输出这个最小值。

$k\leq 10^5$。

------------

若 $k=2^t$，则要配上 $c=5^t$ 得到最优方案 $10^t$。此时 $c\geq 10^{11}$，故不能直接枚举 $c$。

考虑我们是如何构造一个数 $m$ 的。

- $m\leftarrow m\times 10$：数位和不变。

- $m\leftarrow m+1$：若不进位，数位和加一，否则数位和可能减少。

考虑同余最短路，记 $dis_i$ 表示模 $k=i$ 的数中数位和最小的。

连边 $i\rightarrow 10i\bmod k$，边权为 $0$。

连边 $i\rightarrow (i+1)\bmod k$，边权为 $1$。

然后跑 $01\ \rm BFS$ 即可，答案是 $dis_0$。

复杂度 $O(k)$。


