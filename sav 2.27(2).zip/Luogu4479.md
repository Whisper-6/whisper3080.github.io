---
title: Luogu4479 [BJWC2018] 第k大斜率
date: 2025-02-27 17:30:53
tags: [数据结构]
categories:
  - [算法竞赛, 题, 洛谷]
---

**题意**：二维平面上有 $n$ 个点，两两连边得到 $n(n-1)$ 条有向直线，求第 $k$ 大的斜率。忽略斜率不存在的直线。

$n\leq 10^5$，时限 $\texttt{1s}$。

<!-- more -->

-----

首先套一个二分，问题变为：统计有多少条直线的斜率大于等于 $\alpha$。

即对
$$
\left[\dfrac{y_i-y_j}{x_i-x_j}\geq \alpha\right]
$$
求和。

为了方便化不等式和剔除不存在的斜率，规定 $x_i>x_j$。

$$
\dfrac{y_i-y_j}{x_i-x_j}\geq \alpha\quad \Leftrightarrow \quad y_i-y_j\geq \alpha(x_i-x_j)\quad \Leftrightarrow\quad y_i-\alpha x_i\geq y_j-\alpha x_j
$$
按照 $p_i=y_i-\alpha x_i$ 和 $x_i$ 做二维偏序就好了。

复杂度$O(n\log n\log\varepsilon)$。
