﻿---
title: Luogu7575 「PMOI-3」公约数
date: 2025-02-23 19:24:39
tags: [图论]
categories:
  - [算法竞赛, 题, 洛谷]
---

**题意**：给出 $n,m$ 和一个长度为 $n-1$ 的序列 $x$，保证 $x_i$ **互不相同**。

求

$$
\sum_{i_1=1}^m\sum_{i_2=1}^m\cdots\sum_{i_n=1}^m\big[(i_1,i_2)=x_1\big]\big[(i_2,i_3)=x_2\big]\cdots\big[(i_{n-1},i_n)=x_{n-1}\big]
$$
答案对 $998244353$ 取模，$n,m\leq 10^6$，时限 $\texttt{1s}$。

<!-- more -->

------------

直接推式比较吃力，限制呈一条链的形式，考虑 $\rm DP$。

记 $dp[i][j]$ 为：考虑了前 $i$ 个数，且第 $i$ 个填了 $j$ 的方案数。

显然有转移：

$$
\begin{aligned}
dp[i+1][j]&=\sum\limits_{k=1}^m[(j,k)=x_i]dp[i][k]\\
dp[i+1][jx_i]&=\sum\limits_{k=1}^{m/x_i}[j\perp k]dp[i][kx_i]
\end{aligned}
$$

使用反演： 

$$
\begin{aligned}
dp[i+1][jx_i]&=\sum\limits_{k=1}^{m/x_i}dp[i][kx_i]\sum\limits_{d|j,d|k}\mu(d)\\
&=\sum\limits_{d|j}\mu(d)\sum\limits_{d|k}^{m/x_i}dp[i][kx_i]\\
&=\sum\limits_{d|j}\mu(d)\sum\limits_{k=1}^{m/x_id}dp[i][kx_id]
\end{aligned}
$$

预处理 $s[i][d]=\sum\limits_{d|k}dp[i][k]$ ，上式即可 $O\big(d(j)\big)$ 计算。

注意到 $dp[i][j]$ 当 $j$ 为 $x_{i}$ 的倍数时才可能会有值，时间复杂度为 $O\big(\sum_{i=1}^n(m/x_i)\log (m/x_i)\big)$。

又因为 $x_i$ 互不相同，故复杂度为 $O(m\log^2m)$ ，无法通过。

使用狄利克雷前缀和加速，复杂度变为 $O(m\log m\log\log m)$ ，可以通过。


