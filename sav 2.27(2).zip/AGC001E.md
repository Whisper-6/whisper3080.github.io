﻿---
title: AGC001E BBQ Hard
date: 2025-02-25 14:53:07
tags: [动态规划, 组合数学, 多项式]
categories:
  - [算法竞赛, 题, AtCoder]
---

**题意**：给出 $n$ 个数对 $(a_i,b_i)$，求下列式子的值 ：
$$
\sum\limits_{i=1}^n\sum\limits_{j=i+1}^n\dbinom{a_i+a_j+b_i+b_j}{a_i+a_j}
$$
答案对 $10^9+7$ 取模。

$n\leq 2\times 10^5$，$a_i,b_i\leq 2000$，时限 $\texttt{2s}$。

<!-- more -->

------------

## 法一（组合法）

发现 $a,b$ 较小，从此处入手。

为 $\binom{n+m}{n,m}$ 编一个组合意义 ： 从 $(0,0)$ 出发，只能向上或向右走，到达 $(n,m)$ 的方案数。

于是，题目中所求的式子就可以看做 ： 从 $(0,0)$ 出发，到达 $(a_i+a_j,b_i+b_j)$ 的方案数。

平移一下，即改为 ： 从 $(-a_i,-b_i)$ 出发，到达 $(a_j,b_j)$ 的方案数。

于是可以改为计算两两点之间的路径条数总和。减去 $i=j$ 的贡献后除以 $2$ 即可

设 $o[x,y]$ 为到达 $(x,y)$ 的路径条数，则有如下转移 ：

$$
o[x,y]=o[x-1,y]+o[x,y-1]+\sum_i[(-a_i,-b_i)=(x,y)]
$$
复杂度为 $O(ab+n)$。

## 法二（多项式）

简单起见，改记 $b_i\leftarrow b_i+a_i$，并将三角求和改为方形
$$
\text{Ans}=\frac{1}{2}\bigg(\sum_{i=1}^n\sum_{j=1}^n\dbinom{b_i+b_j}{a_i+a_j}-\sum_{i=1}^n\dbinom{2b_i}{2a_i}\bigg)
$$

利用 $\binom{n}{m}=[x^m] (1+x)^n$ 进行构造，并尝试对齐次数
$$
\begin{aligned}
\sum_{i=1}^n\sum\limits_{j=1}^n\dbinom{b_i+b_j}{a_i+a_j}&=\sum\limits_{i=1}^n\sum_{j=1}^n[x^{a_i+a_j}](1+x)^{b_i+b_j}\\
&=[x^0]\sum_{i=1}^n\sum\limits_{j=1}^nx^{-a_i-a_j}(1+x)^{b_i+b_j}\\
&=[x^0]\bigg(\sum_{i=1}^nx^{-a_i}(1+x)^{b_i}\bigg)\\
\end{aligned}
$$

求出 $F(x)=\sum_{i=1}^nx^{-a_i}(1+x)^{b_i}$ 之后暴力平方即可。
$$
\begin{aligned}
F(x)&=\sum_{t=0}^{\max b}(1+x)^t\bigg(\sum_{i=1}^n[b_i=t]x^{-a_i}\bigg)\\
&=\sum_{t=0}^{\max b}A_t(x)(1+x)^t\\
&=A_0(x)+(1+x)\Big(A_1(x)+(1+x)\big(A_2(x)+\dots\big)\Big)
\end{aligned}
$$

其中 $A_t(x)=\sum_{i=0}^n[b_i=t]x^{-a_i}$。

这可以用秦九韶算法快速计算（最后一行从内往外算），总复杂度 $O(n+ab)$。


