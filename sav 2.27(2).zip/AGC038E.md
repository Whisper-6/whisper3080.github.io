﻿---
title: AGC038E Gachapon
date: 2025-02-20 14:21:10
tags: [多项式]
categories:
  - [算法竞赛, 题, AtCoder]
---

**题意** ： 给出权值数组 $A_{1\sim n}$，记 $S=\sum A_{1\sim n}$。

有一个随机数生成器，每次会以 $A_i/S$ 的概率生成数 $i$。

这个随机数生成器不断生成随机数，当所有 $i$ 至少出现 $B_i$ 次时停止，问期望生成的次数。

答案对 $998244353$ 取模。

$n,\sum A,\sum B\leq 400$，时限 $\texttt{3s}$。

<!-- more -->

------------

组合苦弱，代数飞升。我们已经知道这类问题的代数结构，直接大力推式即可。

改记 $A_i\leftarrow A_i/S$。

记生成 $n$ 次时满足“所有 $i$ 至少出现 $B_i$ 次”的概率为 $P[n]$，使用 (P)EGF 刻画排列，有 ：

$$
\begin{aligned}
F(x)&=\prod_{i=1}^n\sum\limits_{j=B_i}^{+\infty}\dfrac{(A_ix)^j}{j!}\\
P[n]&=\big[\tfrac{x^n}{n!}\big]F(x)
\end{aligned}
$$
注意到这同时也是耗时 $T\leq i$ 的概率。于是

$$
{\rm Ans}=\mathbb E(T)=\sum_{i=0}^{+\infty}\mathbb P(T>i)=\sum_{i=0}^{+\infty}\big(1-P[i]\big)
$$
先将 $F$ 变形为更简单的形式。

$$
\begin{aligned}
F(x)&=\prod_{i=1}^n\sum\limits_{j=B_i}^{+\infty}\dfrac{(A_ix)^j}{j!}\\
&=\prod_{i=1}^n\Big(e^{A_ix}-\sum\limits_{j=0}^{B_i-1}\dfrac{(A_ix)^j}{j!}\Big)
\end{aligned}
$$

我们令 $y=e^x$，将其看做二元生成函数。

可以发现 $F$ 能表示为 $\sum_{c}y^cG_c(x)$ 的形式。其中 $G_c(x)$ 是多项式。

具体地，$c$ 的可能取值有 $S$ 个，$G$ 的次数是 $\sum B$ 的。

暴力计算，逐个相乘，复杂度为 $O\big(S(\sum B)^2\big)$，此处是复杂度瓶颈。

$$
\begin{aligned}
{\rm Ans}&=\sum_{n=0}^{+\infty}\big(1-P[i]\big)\\
&=\sum_{n=0}^{+\infty}\Big(1-\big[\tfrac{x^n}{n!}\big]\sum_{c}e^{cx}G_c(x)\Big)\\
\end{aligned}
$$

注意到 $G_{1}(x)=1$ （因为在每个因式中都选了 $e^{A_ix}$ 而 $\sum A=1$），用这一项 $\big[\tfrac{x^n}{n!}\big]e^x$ 抵消掉前面的 $1$。

$$
\begin{aligned}
{\rm Ans}&=\sum_{n=0}^{+\infty}\big[\tfrac{x^n}{n!}\big]\sum_{c,c\neq 1}e^{cx}G_c(x)\\
&=\sum_{n=0}^{+\infty}n!\sum_{c,c\neq 1}\sum_{j=0}^{+\infty}G_c[j][x^{n-j}]e^{cx}\\
&=\sum_{n=0}^{+\infty}n!\sum_{c,c\neq 1}\sum_{j=0}^{+\infty}G_c[j]\dfrac{c^{n-j}}{(n-j)!}\\
&=\sum_{c,c\neq 1}\sum_{j=0}^{+\infty}G_c[j]\sum_{n=0}^{+\infty}n^{\underline j}c^{n-j}\\
&=\sum_{c,c\neq 1}\sum_{j=0}^{+\infty}G_c[j]c^{-j}j!\sum_{n=0}^{+\infty}\binom{n}{j}c^n\\
\end{aligned}
$$

记 $S_j(c)=\sum_{n=0}^{+\infty}\binom{n}{j}c^n$，则有 ：

$$
\begin{aligned}
S_j(c)&=\sum_{n=0}^{+\infty}\binom{n}{j}c^n\\
&=\sum_{n=0}^{+\infty}\binom{n-1}{j}c^n+\sum_{n=1}^{+\infty}\binom{n-1}{j-1}c^n\\
&=cS_j(c)+cS_{j-1}(c)\\
\Rightarrow S_j(c)&=\dfrac{c}{1-c}S_{j-1}(c)
\end{aligned}
$$

可以递推求出所需的 $S_j(c)$ 。


